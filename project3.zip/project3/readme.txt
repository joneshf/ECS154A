Project 3
ECS154A - Chris Nitta - Fall 2013
20 November 2013

Authors:
Steven Avery - 997694781
Hardy Jones - 999397426
Brandon Tyler - 999403734

I can't believe it, but we made a whole CPU. There's state machines, registers, multi clock cycle per instruction, dataout and datain. There's even a memory array hooked up to it so that we can load in the instructions. WOW